final.zip includes:
  final.py
  sprites (folder with all pictures)

To run:
  install python (Windows) or python3 (Mac)
    go to python.org and download most current version of python for your operating system
    follow instructions

  install pygame
    open terminal (Mac) or command line (Windows)
    type "pip install pygame" or "pip3 install pygame"

  download zip from website

  save zip to Downloads

  decompress zip if not downloaded as a folder

  go to location of folder in terminal or command line:
    cd Downloads
    cd final
    "python final.py" or "python3 final.py"
