import pygame
from pygame.locals import *
import os
import sys
import math
import random
import time

pygame.init()

W, H = 800, 447
win = pygame.display.set_mode((W,H))
pygame.display.set_caption('Side Scroller')

bg = pygame.image.load(os.path.join('sprites','newcity.png')).convert()
bgX = 0
bgX2 = bg.get_width()

clock = pygame.time.Clock()
timer = 6000
counter = 0

newSurface = pygame.surface.Surface((W, H))
newSurface.fill((0,0,0))
win.blit(newSurface, (0,0))
startScreen = pygame.image.load(os.path.join('sprites', 'start1.jpg'))
startScreen2 = pygame.image.load(os.path.join('sprites', 'start2.jpg'))
start = True
screen = 1
endingScreen = False
# badEnd = [pygame.image.load(os.path.join('sprites', 'bad1.png')), pygame.image.load(os.path.join('sprites', 'bad2.png')), pygame.image.load(os.path.join('sprites', 'bad3.png')), pygame.image.load(os.path.join('sprites', 'bad4.png')), pygame.image.load(os.path.join('sprites', 'bad5.png')), pygame.image.load(os.path.join('sprites', 'bad6.png'))]
# goodEnd = [pygame.image.load(os.path.join('sprites', 'good1.png')), pygame.image.load(os.path.join('sprites', 'good2.png')), pygame.image.load(os.path.join('sprites', 'good3.png')), pygame.image.load(os.path.join('sprites', 'good4.png'))]

class player(object):
    run = [pygame.image.load(os.path.join('sprites', str(x) + '.png')) for x in range(8,16)]
    jump = [pygame.image.load(os.path.join('sprites', str(x) + '.png')) for x in range(1,8)]
    fall = [pygame.image.load(os.path.join('sprites', '0.png'))]
    slide = [pygame.image.load(os.path.join('sprites', 'S1.png')),pygame.image.load(os.path.join('sprites', 'S2.png')),pygame.image.load(os.path.join('sprites', 'S2.png')),pygame.image.load(os.path.join('sprites', 'S2.png')), pygame.image.load(os.path.join('sprites', 'S2.png')),pygame.image.load(os.path.join('sprites', 'S2.png')), pygame.image.load(os.path.join('sprites', 'S2.png')), pygame.image.load(os.path.join('sprites', 'S2.png')), pygame.image.load(os.path.join('sprites', 'S3.png')), pygame.image.load(os.path.join('sprites', 'S4.png')), pygame.image.load(os.path.join('sprites', 'S5.png'))]
    jumpList = [1,1,1,1,1,1,2,2,2,2,2,2,2,2,2,2,2,2,3,3,3,3,3,3,3,3,3,3,3,3,4,4,4,4,4,4,4,4,4,4,4,4,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,-1,-1,-1,-1,-1,-1,-2,-2,-2,-2,-2,-2,-2,-2,-2,-2,-2,-2,-3,-3,-3,-3,-3,-3,-3,-3,-3,-3,-3,-3,-4,-4,-4,-4,-4,-4,-4,-4,-4,-4,-4,-4]
    def __init__(self, x, y, width, height):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.jumping = False
        self.sliding = False
        self.slideCount = 0
        self.jumpCount = 0
        self.runCount = 0
        self.slideUp = False
        self.falling = False

    def draw(self, win):
        if self.jumping:
            self.y -= self.jumpList[self.jumpCount] * 1.2
            win.blit(self.jump[self.jumpCount//18], (self.x,self.y))
            self.jumpCount += 1
            if self.jumpCount > 108:
                self.jumpCount = 0
                self.jumping = False
                self.runCount = 0
            self.hitbox = (self.x+7, self.y, self.width-24, self.height)
        elif self.sliding or self.slideUp:
            if self.slideCount < 20:
                self.y += 1
            elif self.slideCount == 80:
                self.y -= 19
                self.sliding = False
                self.slideUp = True
            elif self.slideCount > 20 and self.slideCount < 80:
                self.hitbox = (self.x+7, self.y+3, self.width-8, self.height)
            if self.slideCount >= 110:
                self.slideCount = 0
                self.slideUp = False
                self.runCount = 0
                self.hitbox = (self.x-5, self.y, self.width-24, self.height)
            win.blit(self.slide[self.slideCount//10], (self.x,self.y))
            self.slideCount += 1
        else:
            if self.runCount > 42:
                self.runCount = 0
            win.blit(self.run[self.runCount//6], (self.x,self.y))
            self.runCount += 1
            self.hitbox = (self.x+7, self.y, self.width-24, self.height)


class smoke(object):
    img = [pygame.image.load(os.path.join('sprites', 'sm0.png')), pygame.image.load(os.path.join('sprites', 'sm1.png')), pygame.image.load(os.path.join('sprites', 'sm2.png')), pygame.image.load(os.path.join('sprites', 'sm3.png'))]
    def __init__(self, x, y, width, height):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.hitbox = (x, y, width, height)
        self.count = 0

    def draw(self, win):
        self.hitbox = (self.x, self.y, self.width, self.height)
        if self.count >= 8:
            self.count = 0
        win.blit(pygame.transform.scale(self.img[self.count//2], (48,45)), (self.x, self.y))
        self.count += 1

    def collide(self, rect):
        if (rect[0] + rect[2]) > self.hitbox[0] and rect[0] < (self.hitbox[0] + self.hitbox[2]):
            if rect[1] < self.hitbox[1]:
                return True
        return False

class oil(object):
    img = pygame.image.load(os.path.join('sprites', 'oil.png'))
    def __init__(self, x, y, width, height):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.hitbox = (x, y, width, height)
        self.count = 0
    r = random.randrange(0, 2)
    def draw(self, win):
        self.hitbox = (self.x, self.y, self.width, self.height)
        win.blit(self.img, (self.x, self.y))

    def collide(self, rect):
        if (rect[0] + rect[2]) > self.hitbox[0] and rect[0] < (self.hitbox[0] + self.hitbox[2]):
            if (rect[1] + rect[3]) > self.hitbox[1]:
                return True
        return False

class gas(object):
    img = pygame.image.load(os.path.join('sprites', 'gas.png'))
    def __init__(self, x, y, width, height):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.hitbox = (x, y, width, height)
        self.count = 0
    r = random.randrange(0, 2)
    def draw(self, win):
        self.hitbox = (self.x, self.y, self.width, self.height)
        win.blit(self.img, (self.x, self.y))

    def collide(self, rect):
        if (rect[0] + rect[2]) > self.hitbox[0] and rect[0] < (self.hitbox[0] + self.hitbox[2]):
            if (rect[1] + rect[3]) > self.hitbox[1]:
                return True
        return False

class co2(object):
    img = pygame.image.load(os.path.join('sprites', 'co2.png'))
    def __init__(self, x, y, width, height):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.hitbox = (x, y, width, height)
        self.count = 0

    def draw(self, win):
        self.hitbox = (self.x, self.y, self.width, self.height)
        win.blit(self.img, (self.x, self.y))

    def collide(self, rect):
        if (rect[0] + rect[2]) > self.hitbox[0] and rect[0] < (self.hitbox[0] + self.hitbox[2]):
            if rect[1] < self.hitbox[1]:
                return True
        return False

class deforestation(object):
    img = pygame.image.load(os.path.join('sprites', 'deforestation.png'))
    def __init__(self, x, y, width, height):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.hitbox = (x, y, width, height)
        self.count = 0

    def draw(self, win):
        self.hitbox = (self.x+7, self.y+7, self.width-15, self.height-15)
        win.blit(self.img, (self.x, self.y))

    def collide(self, rect):
        if (rect[0] + rect[2]) > self.hitbox[0] and rect[0] < (self.hitbox[0] + self.hitbox[2]):
            if (rect[1] + rect[3]) > self.hitbox[1]:
                return True
        return False

class tower(object):
    img = pygame.image.load(os.path.join('sprites', 'tower.png'))
    def __init__(self, x, y, width, height):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.hitbox = (x, y, width, height)
        self.count = 0

    def draw(self, win):
        self.hitbox = (self.x+7, self.y+7, self.width-15, self.height-15)
        win.blit(self.img, (self.x, self.y))

    def collide(self, rect):
        if (rect[0] + rect[2]) > self.hitbox[0] and rect[0] < (self.hitbox[0] + self.hitbox[2]):
            if (rect[1] + rect[3]) > self.hitbox[1]:
                return True
        return False

class factory(object):
    img = pygame.image.load(os.path.join('sprites', 'factory.png'))
    img2 = pygame.image.load(os.path.join('sprites', 'factory2.png'))
    def __init__(self, x, y, width, height):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.hitbox = (x, y, width, height)
        self.count = 0
    def draw(self, win):
        self.hitbox = (self.x+7, self.y+7, self.width-15, self.height-15)
        win.blit(self.img, (self.x, self.y))

    def collide(self, rect):
        if (rect[0] + rect[2]) > self.hitbox[0] and rect[0] < (self.hitbox[0] + self.hitbox[2]):
            if (rect[1] + rect[3]) > self.hitbox[1]:
                return True
        return False

class factory2(object):
    img = pygame.image.load(os.path.join('sprites', 'factory2.png'))
    def __init__(self, x, y, width, height):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.hitbox = (x, y, width, height)
        self.count = 0
    def draw(self, win):
        self.hitbox = (self.x+7, self.y+7, self.width-15, self.height-15)
        win.blit(self.img, (self.x, self.y))

    def collide(self, rect):
        if (rect[0] + rect[2]) > self.hitbox[0] and rect[0] < (self.hitbox[0] + self.hitbox[2]):
            if (rect[1] + rect[3]) > self.hitbox[1]:
                return True
        return False

class turbine(object):
    img = pygame.image.load(os.path.join('sprites', 'turbine.png'))
    def __init__(self, x, y, width, height):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.hitbox = (x, y, width, height)
        self.count = 0

    def draw(self, win):
        self.hitbox = (self.x, self.y, self.width, self.height)
        win.blit(self.img, (self.x, self.y))

    def collide(self, rect):
        if (rect[0] + rect[2]) > self.hitbox[0] and rect[0] < (self.hitbox[0] + self.hitbox[2]):
            if rect[1] < self.hitbox[1]:
                return True
        return False

class plant(object):
    img = pygame.image.load(os.path.join('sprites', 'plant.png'))
    def __init__(self, x, y, width, height):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.hitbox = (x, y, width, height)
        self.count = 0

    def draw(self, win):
        self.hitbox = (self.x, self.y, self.width, self.height)
        win.blit(self.img, (self.x, self.y))

    def collide(self, rect):
        if (rect[0] + rect[2]) > self.hitbox[0] and rect[0] < (self.hitbox[0] + self.hitbox[2]):
            if (rect[1] + rect[3]) > self.hitbox[1]:
                return True
        return False

class energy(object):
    img = pygame.image.load(os.path.join('sprites', 'energy.png'))
    def __init__(self, x, y, width, height):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.hitbox = (x, y, width, height)
        self.count = 0

    def draw(self, win):
        self.hitbox = (self.x, self.y, self.width, self.height)
        win.blit(self.img, (self.x, self.y))

    def collide(self, rect):
        if (rect[0] + rect[2]) > self.hitbox[0] and rect[0] < (self.hitbox[0] + self.hitbox[2]):
            if (rect[1] + rect[3]) > self.hitbox[1]:
                return True
        return False

class solar(object):
    img = pygame.image.load(os.path.join('sprites', 'solar.png'))
    def __init__(self, x, y, width, height):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.hitbox = (x, y, width, height)
        self.count = 0

    def draw(self, win):
        self.hitbox = (self.x, self.y, self.width, self.height)
        win.blit(self.img, (self.x, self.y))

    def collide(self, rect):
        if (rect[0] + rect[2]) > self.hitbox[0] and rect[0] < (self.hitbox[0] + self.hitbox[2]):
            if (rect[1] + rect[3]) > self.hitbox[1]:
                return True
        return False

class factoryg(object):
    img = pygame.image.load(os.path.join('sprites', 'factoryg.png'))
    def __init__(self, x, y, width, height):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.hitbox = (x, y, width, height)
        self.count = 0

    def draw(self, win):
        self.hitbox = (self.x, self.y, self.width-15, self.height-15)
        win.blit(self.img, (self.x, self.y))

    def collide(self, rect):
        if (rect[0] + rect[2]) > self.hitbox[0] and rect[0] < (self.hitbox[0] + self.hitbox[2]):
            if (rect[1] + rect[3]) > self.hitbox[1]:
                return True
        return False

class tree(object):
    img = pygame.image.load(os.path.join('sprites', 'tree.png'))
    def __init__(self, x, y, width, height):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.hitbox = (x, y, width, height)
        self.count = 0

    def draw(self, win):
        self.hitbox = (self.x+7, self.y+7, self.width-15, self.height-15)
        win.blit(self.img, (self.x, self.y))

    def collide(self, rect):
        if (rect[0] + rect[2]) > self.hitbox[0] and rect[0] < (self.hitbox[0] + self.hitbox[2]):
            if (rect[1] + rect[3]) > self.hitbox[1]:
                return True
        return False

class coin(object):
    img = [pygame.image.load(os.path.join('sprites', 'c1.png')), pygame.image.load(os.path.join('sprites', 'c2.png')), pygame.image.load(os.path.join('sprites', 'c3.png')), pygame.image.load(os.path.join('sprites', 'c4.png')), pygame.image.load(os.path.join('sprites', 'c5.png')), pygame.image.load(os.path.join('sprites', 'c6.png'))]
    def __init__(self, x, y, width, height):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.hitbox = (x, y, width, height)
        self.count = 0

    def draw(self, win):
        self.hitbox = (self.x, self.y, self.width-18, self.height-18)
        if self.count >= 12:
            self.count = 0
        win.blit(pygame.transform.scale(self.img[self.count//2], (30,30)), (self.x, self.y))
        self.count += 1

    def collide(self, rect):
        if (rect[0] + rect[2]) > self.hitbox[0] and rect[0] < (self.hitbox[0] + self.hitbox[2]):
            if rect[1] < self.hitbox[1]:
                return True
        return False

class bad(object):
    img = [pygame.image.load(os.path.join('sprites', 'bad1.png')), pygame.image.load(os.path.join('sprites', 'bad2.png')), pygame.image.load(os.path.join('sprites', 'bad3.png')), pygame.image.load(os.path.join('sprites', 'bad4.png')), pygame.image.load(os.path.join('sprites', 'bad5.png')), pygame.image.load(os.path.join('sprites', 'bad6.png'))]
    def __init__(self, x, y, width, height):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.hitbox = (x, y, width, height)
        self.count = 0

    def draw(self, win):
        self.hitbox = (self.x, self.y, self.width-18, self.height-18)
        if self.count >= 12:
            self.count = 0
        win.blit(pygame.transform.scale(self.img[self.count//2], (800,447)), (self.x, self.y))
        self.count += 1

class good(object):
    img = [pygame.image.load(os.path.join('sprites', 'good1.png')), pygame.image.load(os.path.join('sprites', 'good2.png')), pygame.image.load(os.path.join('sprites', 'good3.png')), pygame.image.load(os.path.join('sprites', 'good4.png'))]
    def __init__(self, x, y, width, height):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.hitbox = (x, y, width, height)
        self.count = 0

    def draw(self, win):
        self.hitbox = (self.x, self.y, self.width-18, self.height-18)
        if self.count >= 8:
            self.count = 0
        win.blit(pygame.transform.scale(self.img[self.count//2], (800,447)), (self.x, self.y))
        self.count += 1

#count = 0
def redrawWindow():
    if(screen == 1):
        win.blit(startScreen, (0,0))
    elif(screen == 2):
        win.blit(startScreen2, (0,0))
    elif(endingScreen == True):
        font = pygame.font.Font(None, 30)
        goodCollected = font.render("Good Items: " + str(good), 1, (255,255,255))
        badCollected = font.render("Bad Items: " + str(bad), 1, (255,255,255))
        coinCollected = font.render("Coins: " + str(coins), 1, (255,255,255))
        if(good + bad == 0):
            win.blit(pygame.image.load(os.path.join('sprites', 'good1.png')), (0,0))
        elif(good/(good + bad) < 0.7):
            win.blit(pygame.image.load(os.path.join('sprites', 'lose.png')), (0,0))
        elif(good/(good + bad) >= 0.7):
            win.blit(pygame.image.load(os.path.join('sprites', 'win.png')), (0,0))
        win.blit(goodCollected, (600, 30))
        win.blit(badCollected, (600, 50))
        win.blit(coinCollected, (600, 70))
    else:
        font = pygame.font.Font(None, 30)
        displayTimer = font.render("Time Remaining: " + str(timer//100), 1, (0,0,0))
        win.blit(bg, (bgX,0))
        win.blit(bg, (bgX2,0))
        runner.draw(win)
        for i in objects:
            i.draw(win)
        win.blit(displayTimer, (580, 30))
    pygame.display.update()

def reset():
    endingScreen = True
    bad = 0
    good = 0
    coins = 0
    timer = 6000
    for i in objects:
        objects.remove(i)
    run = True
    start = True
    screen = 1

runner = player(200, 312, 64, 64)
pygame.time.set_timer(USEREVENT+1,500)
pygame.time.set_timer(USEREVENT+2,random.randrange(2500, 4000))
speed = 30
run = True
bad = 0
good = 0
coins = 0
objects = []
begin = True

while run == True:
    keys = pygame.key.get_pressed()
    if screen == 3 and begin == True:
        begin = False

    if screen == 3:
        for objectt in objects:
            if objectt.collide(runner.hitbox):
                runner.falling = True
                if (isinstance(objectt, smoke) or isinstance(objectt, oil)
                or isinstance(objectt, factory) or isinstance(objectt, co2)
                or isinstance(objectt, deforestation) or isinstance(objectt, factory2)
                or isinstance(objectt, gas) or isinstance(objectt, tower)):
                    bad += 1
                if (isinstance(objectt, turbine) or isinstance(objectt, solar)
                or isinstance(objectt, factoryg) or isinstance(objectt, tree)
                or isinstance(objectt, plant) or isinstance(objectt, energy)):
                    good += 1
                if (isinstance(objectt, coin)):
                    coins += 1
                objects.remove(objectt)

            objectt.x -= 1.4
            if objectt.x < objectt.width * -1:
                objects.pop(objects.index(objectt))

        # print("bad: " + str(bad))
        # print("good: " + str(good))
        # print("coins: " + str(coins))

    bgX -= 1.4
    bgX2 -= 1.4
    if bgX < bg.get_width() * -1:
        bgX = bg.get_width()
    if bgX2 < bg.get_width() * -1:
        bgX2 = bg.get_width()
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False
            pygame.quit()
            quit()
        if event.type == USEREVENT+1:
            speed += 1
        if event.type == USEREVENT+2 and screen == 3:
            r = random.randrange(0, 7)
            r1 = random.randrange(0, 2)
            if r == 0:
                objects.append(smoke(810, 200, 48, 45))
                objects.append(solar(900, 340, 48, 45))
            elif r == 1:
                if r1 == 0:
                    objects.append(factory(810, 330, 50, 50))
                else:
                    objects.append(factory(810, 330, 50, 50))
                objects.append(factoryg(900, 340, 50, 50))
            elif r == 2:
                objects.append(tree(810, 315, 50, 50))
                objects.append(co2(930, 200, 48, 45))
            elif r == 3:
                objects.append(coin(810, 220, 50, 50))
                objects.append(deforestation(900, 330, 48, 45))
            elif r == 4:
                objects.append(tower(820, 330, 50, 50))
                objects.append(energy(950, 340, 48, 45))
            elif r == 5:
                objects.append(plant(830, 340, 48, 45))
                objects.append(tower(900, 330, 50, 50))
                objects.append(smoke(810, 200, 48, 45))
            else:
                if r1 == 0:
                    objects.append(oil(810, 350, 50, 50))
                else:
                    objects.append(gas(810, 350, 50, 50))
                objects.append(turbine(900, 240, 50, 50))
        if event.type == pygame.MOUSEBUTTONDOWN and screen == 1:
            screen = 2
        if event.type == pygame.KEYDOWN and screen == 2:
            screen = 3

    if keys[pygame.K_SPACE] or keys[pygame.K_UP]:
        if not (runner.jumping):
            runner.jumping = True
    if keys[pygame.K_DOWN]:
        if not (runner.sliding):
            runner.sliding = True
    if begin == False:
        counter = counter + 1
        if(counter % 50 == 0):
            timer = timer - 100
        if(timer < 100):
            endingScreen = True
            reset()
    clock.tick(3000)
    redrawWindow()
